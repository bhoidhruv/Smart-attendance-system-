package com.example.smartattendace;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class forgetpass_faculty extends AppCompatActivity {

    private EditText emailField;
    private Button resetPasswordButton, backToLoginButton;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpass_faculty); // XML layout

        emailField = findViewById(R.id.emailField);
        resetPasswordButton = findViewById(R.id.resetPasswordButton);
        backToLoginButton = findViewById(R.id.backToLoginButton);
        auth = FirebaseAuth.getInstance();

        resetPasswordButton.setOnClickListener(v -> {
            String email = emailField.getText().toString().trim();
            if (TextUtils.isEmpty(email)) {
                emailField.setError("Enter your registered email");
                return;
            }

            auth.sendPasswordResetEmail(email)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(forgetpass_faculty.this,
                                "Password reset email sent!", Toast.LENGTH_LONG).show();
                        emailField.setText(""); // Clear input field
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(forgetpass_faculty.this,
                                "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
        });

        // Navigate back to login
        backToLoginButton.setOnClickListener(v -> {
            Intent intent = new Intent(forgetpass_faculty.this, FacultyLogin.class);
            startActivity(intent);
            finish();
        });
    }
}
