package com.example.smartattendace;

import android.util.Log;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EmailSender {

    private static final String TAG = "EmailSender";
    private static final String senderEmail = "your-email@gmail.com"; // Change to your email
    private static final String senderPassword = "your-app-password"; // Use App Password

    public static void sendOTPEmail(final String recipientEmail, final String otp) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                Properties properties = new Properties();
                properties.put("mail.smtp.auth", "true");
                properties.put("mail.smtp.starttls.enable", "true");
                properties.put("mail.smtp.host", "smtp.gmail.com");
                properties.put("mail.smtp.port", "587");

                Session session = Session.getInstance(properties, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(senderEmail, senderPassword);
                    }
                });

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(senderEmail));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
                message.setSubject("Your OTP for Registration");
                message.setText("Your OTP is: " + otp + "\n\nUse this OTP to complete your registration.");

                Transport.send(message);
                Log.d(TAG, "OTP sent successfully to: " + recipientEmail);

            } catch (MessagingException e) {
                Log.e(TAG, "Failed to send OTP: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
}
