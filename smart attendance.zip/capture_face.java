package com.example.smartattendace;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;

public class capture_face extends AppCompatActivity {

    private static final int CAMERA_REQUEST = 100;
    private ImageView faceImageView;
    private Button captureButton, saveFaceButton;
    private Bitmap faceBitmap;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture_face);

        faceImageView = findViewById(R.id.faceImageView);
        captureButton = findViewById(R.id.captureButton);
        saveFaceButton = findViewById(R.id.saveFaceButton);

        // Capture Face Button Click
        captureButton.setOnClickListener(v -> launchCamera());

        // Save Face Button Click
        saveFaceButton.setOnClickListener(v -> saveCapturedFace());
    }

    private void launchCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(cameraIntent, CAMERA_REQUEST);
        } else {
            Toast.makeText(this, "Camera not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK && data != null) {
            Bundle extras = data.getExtras();
            faceBitmap = (Bitmap) extras.get("data");
            faceImageView.setImageBitmap(faceBitmap);
        } else {
            Toast.makeText(this, "Face capture canceled!", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveCapturedFace() {
        if (faceBitmap != null) {
            // Convert Bitmap to Byte Array
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            faceBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] faceData = baos.toByteArray();

            // Pass Image as Byte Array (Safer than passing Bitmap)
            Intent returnIntent = new Intent();
            returnIntent.putExtra("faceData", faceData);
            setResult(RESULT_OK, returnIntent);
            finish();
        } else {
            Toast.makeText(this, "No face captured!", Toast.LENGTH_SHORT).show();
        }
    }
}
