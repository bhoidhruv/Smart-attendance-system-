package com.example.smartattendace;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;

public class StudentRegistrationActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private EditText enrollmentField, nameField, mobileField, emailField, passwordField, confirmPasswordField;
    private Button registerButton, faceRecognitionButton;
    private ImageView facePreview;
    private ProgressBar progressBar;  // ✅ ADDED ProgressBar
    private Bitmap capturedFace;

    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_reg);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("Students");
        storageReference = FirebaseStorage.getInstance().getReference("faces");

        // Initialize UI elements
        enrollmentField = findViewById(R.id.enrollmentField);
        nameField = findViewById(R.id.nameField);
        mobileField = findViewById(R.id.mobileField);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        confirmPasswordField = findViewById(R.id.confirmPasswordField);
        registerButton = findViewById(R.id.registerButton);
        faceRecognitionButton = findViewById(R.id.faceRecognitionButton);
        facePreview = findViewById(R.id.facePreview);
        progressBar = findViewById(R.id.ProgressBar); // ✅ ADDED

        progressBar.setVisibility(View.GONE); // Hide Progress Bar Initially

        // Capture Face Button Click
        faceRecognitionButton.setOnClickListener(v -> captureFace());

        // Register Button Click
        registerButton.setOnClickListener(v -> registerStudent());
    }

    private void captureFace() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK && data != null && data.getExtras() != null) {
            capturedFace = (Bitmap) data.getExtras().get("data");
            facePreview.setImageBitmap(capturedFace);
            faceRecognitionButton.setVisibility(View.GONE); // Hide Button after Capturing
        } else {
            Toast.makeText(this, "Face capture failed. Try again!", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerStudent() {
        String enrollment = enrollmentField.getText().toString().trim();
        String name = nameField.getText().toString().trim();
        String mobile = mobileField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();
        String confirmPassword = confirmPasswordField.getText().toString().trim();

        // Input Validations
        if (TextUtils.isEmpty(enrollment) || enrollment.length() != 13) {
            enrollmentField.setError("Enter a valid 13-digit Enrollment Number");
            return;
        }
        if (TextUtils.isEmpty(name)) {
            nameField.setError("Name is required");
            return;
        }
        if (TextUtils.isEmpty(mobile) || mobile.length() != 10) {
            mobileField.setError("Enter a valid 10-digit Mobile Number");
            return;
        }
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailField.setError("Enter a valid Email ID");
            return;
        }
        if (TextUtils.isEmpty(password) || password.length() < 6) {
            passwordField.setError("Password must be at least 6 characters");
            return;
        }
        if (!password.equals(confirmPassword)) {
            confirmPasswordField.setError("Passwords do not match");
            return;
        }
        if (capturedFace == null) {
            Toast.makeText(this, "Please capture a face image", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show ProgressBar
        progressBar.setVisibility(View.VISIBLE);

        // Register user in Firebase Authentication
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                FirebaseUser firebaseUser = mAuth.getCurrentUser();
                String userId = firebaseUser.getUid();

                // Convert Bitmap to ByteArray
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                capturedFace.compress(Bitmap.CompressFormat.JPEG, 80, baos); // ✅ Compression (80%)
                byte[] faceData = baos.toByteArray();

                // Upload Image to Firebase Storage
                StorageReference faceRef = storageReference.child(userId + ".jpg");
                UploadTask uploadTask = faceRef.putBytes(faceData);
                uploadTask.addOnCompleteListener(upload -> {
                    if (upload.isSuccessful()) {
                        faceRef.getDownloadUrl().addOnSuccessListener(uri -> {
                            // Store Student Data in Firebase Realtime Database
                            HashMap<String, String> studentData = new HashMap<>();
                            studentData.put("enrollment", enrollment);
                            studentData.put("name", name);
                            studentData.put("mobile", mobile);
                            studentData.put("email", email);
                            studentData.put("userId", userId);
                            studentData.put("faceUrl", uri.toString());

                            databaseReference.child(userId).setValue(studentData).addOnCompleteListener(dbTask -> {
                                if (dbTask.isSuccessful()) {
                                    progressBar.setVisibility(View.GONE);
                                    Toast.makeText(StudentRegistrationActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                                    finish();
                                } else {
                                    progressBar.setVisibility(View.GONE);
                                    Toast.makeText(StudentRegistrationActivity.this, "Database Error: " + dbTask.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        });
                    } else {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(StudentRegistrationActivity.this, "Face Upload Failed", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(StudentRegistrationActivity.this, "Authentication Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
