package com.example.smartattendace;

public class StorageReference {
    public StorageReference child(String s) {
        return null;
    }
}
