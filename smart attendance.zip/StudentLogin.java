package com.example.smartattendace;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.example.smartattendace.StudentRegistrationActivity;

public class StudentLogin extends AppCompatActivity {

    private EditText enrollmentField, emailField, passwordField;
    private Button loginButton;
    private TextView forgotPassword, registerLink;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        mAuth = FirebaseAuth.getInstance();

        enrollmentField = findViewById(R.id.enrollmentField);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        forgotPassword = findViewById(R.id.forgotPassword);
        registerLink = findViewById(R.id.registerLink);

        loginButton.setOnClickListener(v -> loginStudent());

        forgotPassword.setOnClickListener(v -> startActivity(new Intent(StudentLogin.this, activity_forgot_password.class)));

        registerLink.setOnClickListener(v -> {
            Intent intent = new Intent(StudentLogin.this, StudentRegistrationActivity.class);
            startActivity(intent);
        });
    }

    private void loginStudent() {
        String enrollment = enrollmentField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (enrollment.length() != 13) {  // Ensure 13-digit Enrollment Number
            enrollmentField.setError("Enter a valid 13-digit Enrollment Number");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            emailField.setError("Email is required");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordField.setError("Password is required");
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        Toast.makeText(StudentLogin.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(StudentLogin.this, DashboardActivity.class));
                        finish();
                    } else {
                        Toast.makeText(StudentLogin.this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}
