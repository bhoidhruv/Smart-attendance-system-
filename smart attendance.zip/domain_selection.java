package com.example.smartattendace;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class domain_selection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domain_selection);

        Button studentButton = findViewById(R.id.studentButton);
        Button facultyButton = findViewById(R.id.facultyButton);

        studentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(domain_selection.this, StudentLogin.class);
                startActivity(intent);
            }
        });

        facultyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(domain_selection.this, FacultyLogin.class);
                startActivity(intent);
            }
        });
    }
}

