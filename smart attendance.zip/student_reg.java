package com.example.smartattendace;

import android.app.Activity;

public class student_reg extends Activity {
}
