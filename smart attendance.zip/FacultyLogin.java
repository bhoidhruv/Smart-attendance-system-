package com.example.smartattendace;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class FacultyLogin extends AppCompatActivity {

    private EditText emailField, passwordField;
    private Button loginButton;
    private TextView forgotPassword, registerHere;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_login);

        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        forgotPassword = findViewById(R.id.forgotPassword);
        registerHere = findViewById(R.id.registerHere);

        mAuth = FirebaseAuth.getInstance();

        // Login Button Click
        loginButton.setOnClickListener(view -> loginUser());

        // Forgot Password Click
        forgotPassword.setOnClickListener(v -> {
            Intent resetIntent = new Intent(FacultyLogin.this, forgetpass_faculty.class);
            startActivity(resetIntent);
        });


        // Registration Click
        registerHere.setOnClickListener(view -> {
            Intent intent = new Intent(FacultyLogin.this, MainActivity.class);
            startActivity(intent);
        });
    }

    private void loginUser() {
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            emailField.setError("Email is required");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordField.setError("Password is required");
            return;
        }

        // Firebase Authentication
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null && user.isEmailVerified()) {
                    Toast.makeText(FacultyLogin.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(FacultyLogin.this, DashboardActivity.class));
                    finish();
                } else {
                    Toast.makeText(FacultyLogin.this, "Please verify your email first.", Toast.LENGTH_LONG).show();
                    mAuth.signOut();
                }
            } else {
                Toast.makeText(FacultyLogin.this, "Login Failed! Check your credentials.", Toast.LENGTH_LONG).show();
            }
        });
    }
}
